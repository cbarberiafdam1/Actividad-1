import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalcularPeriodoTest {
	@Test
	void test() {
		CalcularPeriodo cal = new CalcularPeriodo();
	}

}
